function DOMLoaded()
{
	document.addEventListener("deviceready", phonegapLoaded, false);
}

function phonegapLoaded()
{
	document.addEventListener("pause", OnPause, false);
}

function OnPause()
{
	$(function()
	{
		$("body").append("<h1>Pause</h1>");
		
	});
}